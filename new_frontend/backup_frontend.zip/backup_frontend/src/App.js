import * as React from "react";
import RouteSys from "./routes/RouteSys";


export default function App() {
  return (
      <>
          <RouteSys/>
      </>
  );
}

